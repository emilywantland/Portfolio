﻿namespace Lab_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.gradingGB = new System.Windows.Forms.GroupBox();
            this.grade6Lbl = new System.Windows.Forms.Label();
            this.grade4Lbl = new System.Windows.Forms.Label();
            this.grade3Lbl = new System.Windows.Forms.Label();
            this.grade2Lbl = new System.Windows.Forms.Label();
            this.grade1lbl = new System.Windows.Forms.Label();
            this.threshold5Lbl = new System.Windows.Forms.Label();
            this.threshold4Lbl = new System.Windows.Forms.Label();
            this.threshold3Lbl = new System.Windows.Forms.Label();
            this.threshold2Lbl = new System.Windows.Forms.Label();
            this.threshold1Lbl = new System.Windows.Forms.Label();
            this.gradesLbl = new System.Windows.Forms.Label();
            this.wordsTypedLbl = new System.Windows.Forms.Label();
            this.typedInputLbl = new System.Windows.Forms.Label();
            this.gradeEarnedLbl = new System.Windows.Forms.Label();
            this.titleLbl = new System.Windows.Forms.Label();
            this.wordsTypedInputTxt = new System.Windows.Forms.TextBox();
            this.gradeEarnedOutLbl = new System.Windows.Forms.Label();
            this.keyboardPB = new System.Windows.Forms.PictureBox();
            this.calcBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.gradingGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.keyboardPB)).BeginInit();
            this.SuspendLayout();
            // 
            // gradingGB
            // 
            this.gradingGB.Controls.Add(this.grade6Lbl);
            this.gradingGB.Controls.Add(this.grade4Lbl);
            this.gradingGB.Controls.Add(this.grade3Lbl);
            this.gradingGB.Controls.Add(this.grade2Lbl);
            this.gradingGB.Controls.Add(this.grade1lbl);
            this.gradingGB.Controls.Add(this.threshold5Lbl);
            this.gradingGB.Controls.Add(this.threshold4Lbl);
            this.gradingGB.Controls.Add(this.threshold3Lbl);
            this.gradingGB.Controls.Add(this.threshold2Lbl);
            this.gradingGB.Controls.Add(this.threshold1Lbl);
            this.gradingGB.Controls.Add(this.gradesLbl);
            this.gradingGB.Controls.Add(this.wordsTypedLbl);
            this.gradingGB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gradingGB.Location = new System.Drawing.Point(350, 82);
            this.gradingGB.Name = "gradingGB";
            this.gradingGB.Size = new System.Drawing.Size(223, 269);
            this.gradingGB.TabIndex = 0;
            this.gradingGB.TabStop = false;
            // 
            // grade6Lbl
            // 
            this.grade6Lbl.AutoSize = true;
            this.grade6Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grade6Lbl.Location = new System.Drawing.Point(137, 226);
            this.grade6Lbl.Name = "grade6Lbl";
            this.grade6Lbl.Size = new System.Drawing.Size(20, 20);
            this.grade6Lbl.TabIndex = 12;
            this.grade6Lbl.Text = "A";
            // 
            // grade4Lbl
            // 
            this.grade4Lbl.AutoSize = true;
            this.grade4Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grade4Lbl.Location = new System.Drawing.Point(137, 189);
            this.grade4Lbl.Name = "grade4Lbl";
            this.grade4Lbl.Size = new System.Drawing.Size(20, 20);
            this.grade4Lbl.TabIndex = 11;
            this.grade4Lbl.Text = "B";
            // 
            // grade3Lbl
            // 
            this.grade3Lbl.AutoSize = true;
            this.grade3Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grade3Lbl.Location = new System.Drawing.Point(137, 151);
            this.grade3Lbl.Name = "grade3Lbl";
            this.grade3Lbl.Size = new System.Drawing.Size(20, 20);
            this.grade3Lbl.TabIndex = 10;
            this.grade3Lbl.Text = "C";
            // 
            // grade2Lbl
            // 
            this.grade2Lbl.AutoSize = true;
            this.grade2Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grade2Lbl.Location = new System.Drawing.Point(137, 114);
            this.grade2Lbl.Name = "grade2Lbl";
            this.grade2Lbl.Size = new System.Drawing.Size(21, 20);
            this.grade2Lbl.TabIndex = 9;
            this.grade2Lbl.Text = "D";
            // 
            // grade1lbl
            // 
            this.grade1lbl.AutoSize = true;
            this.grade1lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grade1lbl.Location = new System.Drawing.Point(137, 77);
            this.grade1lbl.Name = "grade1lbl";
            this.grade1lbl.Size = new System.Drawing.Size(19, 20);
            this.grade1lbl.TabIndex = 8;
            this.grade1lbl.Text = "F";
            // 
            // threshold5Lbl
            // 
            this.threshold5Lbl.AutoSize = true;
            this.threshold5Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threshold5Lbl.Location = new System.Drawing.Point(19, 226);
            this.threshold5Lbl.Name = "threshold5Lbl";
            this.threshold5Lbl.Size = new System.Drawing.Size(92, 20);
            this.threshold5Lbl.TabIndex = 7;
            this.threshold5Lbl.Text = "76 and over";
            // 
            // threshold4Lbl
            // 
            this.threshold4Lbl.AutoSize = true;
            this.threshold4Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threshold4Lbl.Location = new System.Drawing.Point(19, 189);
            this.threshold4Lbl.Name = "threshold4Lbl";
            this.threshold4Lbl.Size = new System.Drawing.Size(50, 20);
            this.threshold4Lbl.TabIndex = 6;
            this.threshold4Lbl.Text = "51-75";
            // 
            // threshold3Lbl
            // 
            this.threshold3Lbl.AutoSize = true;
            this.threshold3Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threshold3Lbl.Location = new System.Drawing.Point(19, 151);
            this.threshold3Lbl.Name = "threshold3Lbl";
            this.threshold3Lbl.Size = new System.Drawing.Size(50, 20);
            this.threshold3Lbl.TabIndex = 5;
            this.threshold3Lbl.Text = "31-50";
            // 
            // threshold2Lbl
            // 
            this.threshold2Lbl.AutoSize = true;
            this.threshold2Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threshold2Lbl.Location = new System.Drawing.Point(19, 114);
            this.threshold2Lbl.Name = "threshold2Lbl";
            this.threshold2Lbl.Size = new System.Drawing.Size(50, 20);
            this.threshold2Lbl.TabIndex = 4;
            this.threshold2Lbl.Text = "16-30";
            // 
            // threshold1Lbl
            // 
            this.threshold1Lbl.AutoSize = true;
            this.threshold1Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threshold1Lbl.Location = new System.Drawing.Point(19, 77);
            this.threshold1Lbl.Name = "threshold1Lbl";
            this.threshold1Lbl.Size = new System.Drawing.Size(41, 20);
            this.threshold1Lbl.TabIndex = 3;
            this.threshold1Lbl.Text = "0-15";
            // 
            // gradesLbl
            // 
            this.gradesLbl.AutoSize = true;
            this.gradesLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gradesLbl.Location = new System.Drawing.Point(137, 40);
            this.gradesLbl.Name = "gradesLbl";
            this.gradesLbl.Size = new System.Drawing.Size(68, 20);
            this.gradesLbl.TabIndex = 2;
            this.gradesLbl.Text = "Grades";
            // 
            // wordsTypedLbl
            // 
            this.wordsTypedLbl.AutoSize = true;
            this.wordsTypedLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordsTypedLbl.Location = new System.Drawing.Point(15, 40);
            this.wordsTypedLbl.Name = "wordsTypedLbl";
            this.wordsTypedLbl.Size = new System.Drawing.Size(60, 20);
            this.wordsTypedLbl.TabIndex = 1;
            this.wordsTypedLbl.Text = "Words";
            // 
            // typedInputLbl
            // 
            this.typedInputLbl.AutoSize = true;
            this.typedInputLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typedInputLbl.Location = new System.Drawing.Point(36, 99);
            this.typedInputLbl.Name = "typedInputLbl";
            this.typedInputLbl.Size = new System.Drawing.Size(149, 20);
            this.typedInputLbl.TabIndex = 1;
            this.typedInputLbl.Text = "Enter Words Typed:";
            // 
            // gradeEarnedLbl
            // 
            this.gradeEarnedLbl.AutoSize = true;
            this.gradeEarnedLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gradeEarnedLbl.Location = new System.Drawing.Point(71, 152);
            this.gradeEarnedLbl.Name = "gradeEarnedLbl";
            this.gradeEarnedLbl.Size = new System.Drawing.Size(118, 20);
            this.gradeEarnedLbl.TabIndex = 2;
            this.gradeEarnedLbl.Text = "Grade Earned: ";
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLbl.Location = new System.Drawing.Point(29, 31);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(539, 32);
            this.titleLbl.TabIndex = 3;
            this.titleLbl.Text = "Nimble Fingers Typing School Grading";
            // 
            // wordsTypedInputTxt
            // 
            this.wordsTypedInputTxt.Location = new System.Drawing.Point(191, 96);
            this.wordsTypedInputTxt.Name = "wordsTypedInputTxt";
            this.wordsTypedInputTxt.Size = new System.Drawing.Size(100, 26);
            this.wordsTypedInputTxt.TabIndex = 4;
            // 
            // gradeEarnedOutLbl
            // 
            this.gradeEarnedOutLbl.BackColor = System.Drawing.SystemColors.Window;
            this.gradeEarnedOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeEarnedOutLbl.Location = new System.Drawing.Point(191, 147);
            this.gradeEarnedOutLbl.Name = "gradeEarnedOutLbl";
            this.gradeEarnedOutLbl.Size = new System.Drawing.Size(100, 26);
            this.gradeEarnedOutLbl.TabIndex = 5;
            // 
            // keyboardPB
            // 
            this.keyboardPB.Image = ((System.Drawing.Image)(resources.GetObject("keyboardPB.Image")));
            this.keyboardPB.Location = new System.Drawing.Point(26, 219);
            this.keyboardPB.Name = "keyboardPB";
            this.keyboardPB.Size = new System.Drawing.Size(318, 148);
            this.keyboardPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.keyboardPB.TabIndex = 6;
            this.keyboardPB.TabStop = false;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(75, 196);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(100, 39);
            this.calcBtn.TabIndex = 7;
            this.calcBtn.Text = "Calculate";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearBtn.Location = new System.Drawing.Point(191, 196);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(100, 39);
            this.clearBtn.TabIndex = 8;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearBtn;
            this.ClientSize = new System.Drawing.Size(618, 401);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.keyboardPB);
            this.Controls.Add(this.gradeEarnedOutLbl);
            this.Controls.Add(this.wordsTypedInputTxt);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.gradeEarnedLbl);
            this.Controls.Add(this.typedInputLbl);
            this.Controls.Add(this.gradingGB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Lab 7";
            this.gradingGB.ResumeLayout(false);
            this.gradingGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.keyboardPB)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gradingGB;
        private System.Windows.Forms.Label wordsTypedLbl;
        private System.Windows.Forms.Label grade6Lbl;
        private System.Windows.Forms.Label grade4Lbl;
        private System.Windows.Forms.Label grade3Lbl;
        private System.Windows.Forms.Label grade2Lbl;
        private System.Windows.Forms.Label grade1lbl;
        private System.Windows.Forms.Label threshold5Lbl;
        private System.Windows.Forms.Label threshold4Lbl;
        private System.Windows.Forms.Label threshold3Lbl;
        private System.Windows.Forms.Label threshold2Lbl;
        private System.Windows.Forms.Label threshold1Lbl;
        private System.Windows.Forms.Label gradesLbl;
        private System.Windows.Forms.Label typedInputLbl;
        private System.Windows.Forms.Label gradeEarnedLbl;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.TextBox wordsTypedInputTxt;
        private System.Windows.Forms.Label gradeEarnedOutLbl;
        private System.Windows.Forms.PictureBox keyboardPB;
        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.Button clearBtn;
    }
}

