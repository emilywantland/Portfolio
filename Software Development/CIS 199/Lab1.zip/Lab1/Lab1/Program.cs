﻿//Grading ID: N2466
//Section: CIS 199-75
//Lab: 1
//Due Date: January 20, 2019
//This file lists my grading ID, hobbies, and favorite book and movie.

using System;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grading ID:      N2466");
            Console.WriteLine("Hobbies:         Entertaining friends and reading");
            Console.WriteLine("Favorite Book:   A Thousand Splendid Suns");
            Console.WriteLine("Favorite Movie:  Wonder Woman");
        }
    }
}
