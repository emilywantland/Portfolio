﻿using System;
using static System.Console;
class MultiplicationTable
{
    static void Main()
    {
        int number;

        int timesOne;
        int timesTwo;
        int timesThree;
        int timesFour;
        int timesFive;
        int timesSix;
        int timesSeven;
        int timesEight;
        int timesNine;
        int timesTen;

        const int ONE = 1;
        const int TWO = 2;
        const int THREE = 3;
        const int FOUR = 4;
        const int FIVE = 5;
        const int SIX = 6;
        const int SEVEN = 7;
        const int EIGHT = 8;
        const int NINE = 9;
        const int TEN = 10;

        Write("Enter an integer: ");
        number = int.Parse(ReadLine());

        timesOne = ONE * number;
        timesTwo = TWO * number;
        timesThree = THREE * number;
        timesFour = FOUR * number;
        timesFive = FIVE * number;
        timesSix = SIX * number;
        timesSeven = SEVEN * number;
        timesEight = EIGHT * number;
        timesNine = NINE * number;
        timesTen = TEN * number;

        WriteLine($"{ONE} x {number} = {timesOne}");
        WriteLine($"{TWO} x {number} = {timesTwo}");
        WriteLine($"{THREE} x {number} = {timesThree}");
        WriteLine($"{FOUR} x {number} = {timesFour}");
        WriteLine($"{FIVE} x {number} = {timesFive}");
        WriteLine($"{SIX} x {number} = {timesSix}");
        WriteLine($"{SEVEN} x {number} = {timesSeven}");
        WriteLine($"{EIGHT} x {number} = {timesEight}");
        WriteLine($"{NINE} x {number} = {timesNine}");
        WriteLine($"{TEN} x {number} = {timesTen}");
    }
}
