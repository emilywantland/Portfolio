﻿using static System.Console;
class CountVowelsModularized
{
    public static void Main()
    {
        Write("Enter a phrase: ");
        string phrase = ReadLine();

        WriteLine($"You entered {CountVowels(phrase)} vowels.");
    }

    public static int CountVowels(string phrase)
    {

        int count = 0;

        phrase = phrase.ToUpper();

        foreach (char vowel in phrase)
        {
            if (vowel == 'A' || vowel == 'E' || vowel == 'I' || vowel == 'O' || vowel == 'U')
            {
                ++count;
            }
        }

        return count;
    }
}