﻿using System;
using static System.Console;
public class FineForOverdueBooks
{
    public static void Main()
    {
        Write("Enter the number of books: ");
        int books = int.Parse(ReadLine());

        Write("Enter the number of days: ");
        int days = int.Parse(ReadLine());

        DisplayFine(books, days);
    }

    public static void DisplayFine(int books, int days)
    {
        double fine;

        if (days <= 7)
        {
            fine = days * books * 0.10;
        }
            
        else
        {
            fine = books * (0.70 + (days - 7) * 0.20);
        }

        WriteLine($"The fine for {books} book(s) for {days} day(s) is {fine:C}");
    }
}