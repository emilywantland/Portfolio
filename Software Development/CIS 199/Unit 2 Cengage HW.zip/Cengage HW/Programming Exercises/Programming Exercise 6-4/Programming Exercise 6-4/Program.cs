﻿using static System.Console;
class CheckZips
{
    static void Main()
    {
        string[] zips = {"12789", "54012", "54481", "54982", "60007",
                         "60103", "60187", "60188", "71244", "90210"};

        string enteredZip;
        bool isValidZip = false;

        Write("Please enter a zip: ");
        enteredZip = (ReadLine());

        for (int x = 0; x < zips.Length && !isValidZip; ++x)
        {
            if (enteredZip == zips[x])
            {
                isValidZip = true;

            }

        }

        if (isValidZip)
        {
            WriteLine($"Delivery to {enteredZip} ok.");
        }

        else
        {
            WriteLine($"Sorry - no delivery to {enteredZip}.");
        }

    }
}