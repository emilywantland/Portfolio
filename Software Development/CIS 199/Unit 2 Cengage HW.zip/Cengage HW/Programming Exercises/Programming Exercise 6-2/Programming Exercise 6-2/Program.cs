﻿using System;
using static System.Console;
class TestScoreList
{
    static void Main()
    {
        const int MAX_SCORES = 8; // Array upper limit

        decimal[] scores;          // Partially-filled array of scores
                                   // Filled portion from [0] - [count-1]
        decimal currentScore;      // Currently entered score
        decimal totalScores = 0;   // Running total of entered scores
        decimal meanScore;         // Calculated mean of entered scores
        int scoreCount = 0;        // How many in partially-filled array
        bool moreScores = true;    // Haven't hit max yet

        scores = new decimal[MAX_SCORES]; // Allocate spots for up to max scores

        WriteLine("Enter scores, negative # to stop");
        WriteLine($"Max of {MAX_SCORES} employees\n");

        // Loop until hit max or no more scores
        for (int i = 0; (i < MAX_SCORES) && moreScores; i++)
        {
            Write("Enter score {0}: ", i + 1);
            currentScore = decimal.Parse(ReadLine());

            if (currentScore >= 0) // Amount OK, so include
            {
                scores[i] = currentScore;
                totalScores += currentScore;
                scoreCount++;
            }
            else // Cause loop to stop
                moreScores = false;
        }

        meanScore = totalScores / scoreCount;

        for (int i = 0; i < scoreCount; i++)
            WriteLine($"Test #: {i} {scores[i]} From average: {(scores[i] - meanScore)}");

    }
}