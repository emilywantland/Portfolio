﻿using System;
using static System.Console;
class ArrayDemo
{
    static void Main()
    {
        int[] nums = { 7, 6, 3, 2, 10, 8, 4, 5, 9, 1 };
        
        int choice;
        int position;

        Write("Enter Choice: ");
        choice = int.Parse(ReadLine());

        while (choice != 4)
        {
            if (choice == 1)
            {
                for (int index = 0; index < nums.Length; ++index)
                    Write($"{nums[index]} ");
                WriteLine();
            }

            else if (choice == 2)
            {
                for (int index = nums.Length - 1; index >= 0; --index)
                    Write($"{nums[index]} ");
                WriteLine();
            }

            else if (choice == 3)
            {
                Write("Enter position: ");
                position = int.Parse(ReadLine());
                WriteLine($"{nums[position]}");
            }

            Write("Enter Choice: ");
            choice = int.Parse(ReadLine());
        }
    }
}