﻿// Uses DisplayWebAddress method three times
using static System.Console;
class DebugSeven1
{
    static void Main()
    {
        string phrase;
        int count = 0;

        Write("Enter a phrase: ");
        phrase = ReadLine();
        phrase = phrase.ToUpper();

        foreach (char ch in phrase)
            if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
                ++count;
         WriteLine($"You entered {count} vowels.");
    }
}