﻿using System;
using static System.Console;
class CheckCredit
{
    static void Main()
    {
        //Naming variables
        int credit = 0;

        //Parsing input
        Write("Enter credit: ");
        credit = int.Parse(ReadLine());

        //Output if statements
        if (credit < 8000)
            WriteLine("Approved");
        else
            WriteLine("You have exceeded the credit limit");
    }
}
