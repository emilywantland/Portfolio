﻿using static System.Console;
class InchesToCentimetersInteractive
{
    static void Main()
    {

        const double CENTIMETERS = 2.54;
        string inchesAsString;
        double inches;
        System.Console.Write("Please enter the number of inches you would like to convert: ");
        inchesAsString = System.Console.ReadLine();
        inches = double.Parse(inchesAsString);
        System.Console.WriteLine($"{inches} inches is {inches * CENTIMETERS} centimeters.");
    }
}

