﻿using static System.Console;
class StopSign
{
    static void Main()
    {
        WriteLine("{0, 9}", "XXXXXX");
        WriteLine("{0, 2}{0, 9}", "X", "X");
        WriteLine("{0, 1}", "X   STOP   X");
        WriteLine("{0, 2}{0, 9}", "X", "X");
        WriteLine("{0, 9}", "XXXXXX");
        WriteLine("{0, 7}", "X");
        WriteLine("{0, 7}", "X");
        WriteLine("{0, 7}", "X");
    }
}