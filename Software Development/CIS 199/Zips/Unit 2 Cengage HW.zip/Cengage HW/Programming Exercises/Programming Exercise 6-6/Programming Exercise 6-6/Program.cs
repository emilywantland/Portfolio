﻿using System;
using static System.Console;
class ChatAWhile
{
    static void Main()
    {
        int[] areaCode = new int[] { 262, 414, 608, 715, 815, 920 };
        double[] perMinuteRate = new double[] { 0.07, 0.10, 0.05, 0.16, 0.24, 0.14 };

        string inputCode;
        string inputLength;
        int validAreaCode;
        double validLength;
        double totalCharge = 0;
        double areaCodePerMinuteRate = 0;

        WriteLine("Please enter your area code: ");
        inputCode = ReadLine();
        validAreaCode = Convert.ToInt32(inputCode);

        WriteLine("Please enter the  length of the call: ");
        inputLength = ReadLine();
        validLength = Convert.ToDouble(inputLength);

        bool found = false;

        for (int x = 0; x < areaCode.Length; --x)
        {
            if (validAreaCode == areaCode[x])
            {
                found = true;
                areaCodePerMinuteRate = perMinuteRate[x];
                totalCharge = areaCodePerMinuteRate * validLength;
            }
        }

        if (found)
        {
            WriteLine($"Your phone call to area {validAreaCode} costs {areaCodePerMinuteRate} per minute");
            WriteLine($"For {validLength} minutes the total is {totalCharge:C}");
           // Your phone call to area 715 costs $0.16 per minute
           // For 22 minutes the total is $3.52
        }

        else
        {
            WriteLine($"Sorry - no calls allowed to area {validAreaCode}.");
        }
    }
}
