﻿using System;
using static System.Console;
class PaintingEstimate
{
    static void Main()
    {
       GetCost();
    }

    public static double GetCost()
    {
        Write("Enter the length of the room (in feet): ");
        double length = double.Parse(ReadLine());

        Write("Enter the width of the room (in feet): ");
        double width = double.Parse(ReadLine());

        double totalCost = ((length * 9 * 2) + (width * 9 * 2)) * 6;

        WriteLine($"{totalCost:C}");

        return totalCost;
    }
}