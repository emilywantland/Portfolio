﻿using System;
using static System.Console;
class ConvertMilesToKilometers
{
    static void Main()
    {
        Write("Enter the number of miles: ");
        double miles = double.Parse(ReadLine());

        double kilometers;

        kilometers = ConvertToKilometers(miles);

        WriteLine($"{kilometers}");
    }

    public static double ConvertToKilometers(double miles)
    {
        double kilometers = 1.60934 * miles;

        return kilometers;
    }
}