﻿using System;
using static System.Console;
class CountVowels
{
    static void Main()
    {
        string word = "";
        string letter = "aeiouAEIOU";
        int letterCount = 0;

        Write("Enter a sentence: ");
        word = ReadLine();

        for (int i = 0; i < word.Length; i++)
        {
            if (letter.Contains(word.Substring(i, 1)))
            {
                letterCount += 1;
            }
        }
        WriteLine($"Total Vowels: {letterCount}");
    }
}
