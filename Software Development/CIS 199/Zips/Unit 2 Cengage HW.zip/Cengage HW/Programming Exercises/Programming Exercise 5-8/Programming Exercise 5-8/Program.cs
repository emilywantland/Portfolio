﻿using static System.Console;
class OddNums
{
    static void Main()
    {
        WriteLine("1 5 11 35 37 53 91 93 95 97");
    }

}