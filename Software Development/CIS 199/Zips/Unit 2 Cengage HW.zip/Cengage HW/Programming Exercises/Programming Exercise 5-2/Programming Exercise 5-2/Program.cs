﻿using System;
using static System.Console;
class SumInts
{
    static void Main()
    {
        int number;
        bool validInt = true;
        const int QUIT = 999;
        int sum = 0;

        Write("Enter a number (999 to stop): ");
        validInt = int.TryParse(ReadLine(), out number);

        while (number != QUIT)
        {
            if (!validInt)
            {
                WriteLine("Reenter a valid number");
            }

            else
            {
                sum += number;
            }

            Write("Enter a number (999 to stop): ");
            validInt = int.TryParse(ReadLine(), out number);
        }

        WriteLine($"The sum of all entered valid numbers is {sum}.");
    }
}