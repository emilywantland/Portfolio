﻿// GetData() method accepts order number and quantity
// that are used in the Main() method
// Price is $3.99 each

using System;
using static System.Console;
class DebugEight1
{
    static void Main()
    {
        int order = 0;
        int amount = 0;
        double total;
        const double PRICE_EACH = 3.99;

        GetData(out order, out amount);

        total = amount * PRICE_EACH;

        WriteLine($"Order #{order}. Quantity ordered = {amount}");
        WriteLine($"Total is {total:C}");
    }

    public static void GetData(out int order, out int amount)
    {
        int s1;
        int s2;

        Write("Enter order number: ");
        s1 = int.Parse(ReadLine());

        Write("Enter quantity: ");
        s2 = int.Parse(ReadLine());

        order = s1;
        amount = s2;
    }
}
