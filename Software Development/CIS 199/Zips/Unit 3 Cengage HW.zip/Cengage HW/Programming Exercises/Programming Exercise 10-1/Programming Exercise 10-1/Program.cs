﻿using static System.Console;
class LetterDemo
{
    static void Main()
    {
        Letter myLetter = new Letter();
        myLetter.Name = "Emily";
        myLetter.Date = "July 13, 2019";

        CertifiedLetter hisLetter = new CertifiedLetter();
        hisLetter.Name = "Adam";
        hisLetter.Date = "April, 29, 2019";

        hisLetter.trackingNumber = 1001709;

        WriteLine(myLetter);
        WriteLine(hisLetter);
    }
}

class Letter
{
    public string Name { get; set; }
    public string Date { get; set; }

    public override string ToString()
    {
        return (GetType() + " " + "Name: " + Name + " " + "Date: " + Date);
    }
}

class CertifiedLetter : Letter
{
    public int trackingNumber { get; set; }

    public override string ToString()
    {
        return (GetType() + " " + "Name: " + Name + " " + "Date: " + Date + " " + "Tracking Number: " + trackingNumber);
    }
}
