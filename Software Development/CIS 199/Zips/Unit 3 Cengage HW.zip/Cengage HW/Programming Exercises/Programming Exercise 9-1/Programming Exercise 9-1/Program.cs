﻿using static System.Console;
class TestSoccerPlayer
{
    static void Main()
    {
        SoccerPlayer sp = new SoccerPlayer();

        sp.Name = "Wantland";
        sp.JerseyNum = 47;
        sp.Goals = 7;
        sp.Assists = 13;

        WriteLine($"Name: {sp.Name}");
        WriteLine($"Jersey Num: {sp.JerseyNum}");
        WriteLine($"Goals: {sp.Goals}");
        WriteLine($"Assists {sp.Assists}");
    }
}

class SoccerPlayer
{
    public string Name { get; set; }
    public int JerseyNum { get; set; }
    public int Goals { get; set; }
    public int Assists { get; set; }
}