﻿using System;
using static System.Console;
class MoveEstimator
{
    static void Main()
    {
        //Listing constant rates
        const double HOUR_RATE = 150;
        const double MILE_RATE = 2;
        const double BASE_RATE = 200;

        //Naming
        string miles;
        string hours;
        double milesInvolved;
        double hoursRequired;

        //Asking the user to enter the hours required and converting the text into an integer
        System.Console.Write("Please enter the number of hours required: ");
        hours = System.Console.ReadLine();
        hoursRequired = double.Parse(hours);

        //Asking the user to enter the miles driven and converting the text into an integer
        System.Console.Write("Please enter the number of miles involved: ");
        miles = System.Console.ReadLine();
        milesInvolved = double.Parse(miles);

        //Naming the calculations
        double milesCalc;
        double hoursCalc;
        double finalBase;
        double estimate;

        milesCalc = milesInvolved * MILE_RATE;
        hoursCalc = hoursRequired * HOUR_RATE;
        finalBase = BASE_RATE;
        estimate = milesCalc + hoursCalc + finalBase;

        //Outputting the calulation
        System.Console.WriteLine($"For a move taking {hours} hours and going {miles} miles the estimate is {estimate:C}.");
    }
}