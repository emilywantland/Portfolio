﻿using static System.Console;
class BurmaShave
{
    static void Main()
    {
        WriteLine("Shaving brushes");
        WriteLine("You'll soon see 'em");
        WriteLine("On a shelf");
        WriteLine("In some museum");
        WriteLine("Burma Shave");
    }
}
