﻿using System;
using static System.Console;
class CheckMonth
{
    static void Main()
    {
        //Naming variables
        int number;
        int month = 1;

        //Parsing input
        Write("Enter the month number: ");
        number = int.Parse(ReadLine());

        //If statements
        if (number == 1)
            month = 1;
        else if (number == 2)
            month = 2;
        else if (number == 3)
            month = 3;
        else if (number == 4)
            month = 4;
        else if (number == 5)
            month = 5;
        else if (number == 6)
            month = 6;
        else if (number == 7)
            month = 7;
        else if (number == 8)
            month = 8;
        else if (number == 9)
            month = 9;
        else if (number == 10)
            month = 10;
        else if (number == 11)
            month = 11;
        else if (number == 12)
            month = 12;

        //Output if statements
        if (month <= 12 && month != 0)
            WriteLine($"{month} is a valid month.");
        else
            WriteLine("Invalid month");
    }
}