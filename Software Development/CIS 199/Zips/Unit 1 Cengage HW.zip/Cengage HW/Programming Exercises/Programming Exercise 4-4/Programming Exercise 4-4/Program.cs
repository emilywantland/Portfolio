﻿using System;
using static System.Console;
class Hurricane
{
    static void Main()
    {
        //Naming variables
        int speed;
        int category = 0;

        //Parsing input
        Write("Enter speed: ");
        speed = int.Parse(ReadLine());

        //If statements
        if (speed >= 157)
            category = 5;
        else if (speed >= 130)
            category = 4;
        else if (speed >= 111)
            category = 3;
        else if (speed >= 96)
            category = 2;
        else if (speed >= 74)
            category = 1;

        //Output if statements
        if (category >= 1)
            WriteLine($"This is a category {category} hurricane");
        else
            WriteLine("This is not a hurricane");
    }
}