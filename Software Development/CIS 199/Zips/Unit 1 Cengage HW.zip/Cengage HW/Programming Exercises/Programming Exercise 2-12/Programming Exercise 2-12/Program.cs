﻿using System;
using static System.Console;
class MakeChange
{
    static void Main()
    {
        //Naming constants
        const double FRACTION = 1.8;
        const double WHOLE = 32;

        //Naming strings
        string fahrenheit;
        double fahren;
        double celsius;
        double finalCelsius;

        //Asking the user to enter the degree in fahrenheit and converting into a numeral
        System.Console.Write("Please enter the degree in fahrenheit: ");
        fahrenheit = System.Console.ReadLine();
        fahren = double.Parse(fahrenheit);

        //Naming the calculations
        celsius = fahren - WHOLE;
        finalCelsius = celsius / FRACTION;

        //Outputting the calulation
        System.Console.WriteLine($"{fahren:F1} F is {finalCelsius:F1} C");
    }
}
