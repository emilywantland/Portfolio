﻿using System;
using static System.Console;
class FahrenheitToCelsius
{
    static void Main()
    {
        // Declaring strings and variables
        string dollarAmount;
        int dollarBreakdown;

        int twenties;
        int tens;
        int fives;
        int ones;

        //Asking the user to enter the dollar amount
        System.Console.Write("Please enter the dollar amount: ");
        dollarAmount = System.Console.ReadLine();
        dollarBreakdown = int.Parse(dollarAmount);

        //Naming the calculations
        twenties = dollarBreakdown / 20;
        dollarBreakdown = dollarBreakdown % 20;
        tens = dollarBreakdown / 10;
        dollarBreakdown = dollarBreakdown % 10;
        fives = dollarBreakdown / 5;
        dollarBreakdown = dollarBreakdown % 5;
        ones = dollarBreakdown / 1;

        //Outputting the calulation
        System.Console.WriteLine($"twenties: {twenties:F0} tens: {tens:F0} fives: {fives:F0} ones: {ones:F0}.");
    }
}
