﻿using static System.Console;
class Twitter
{
    static void Main()
    {
        WriteLine("Enter the tweet ");
        string message = ReadLine();

        if (message.Length <= 140)
        {
            WriteLine("The message is okay.");
        }
        else
        {
            WriteLine("The message is too long.");
        }
    }
}