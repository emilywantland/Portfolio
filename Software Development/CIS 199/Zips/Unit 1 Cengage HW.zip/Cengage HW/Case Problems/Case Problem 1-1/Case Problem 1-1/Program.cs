﻿using static System.Console;
class GreenvilleMotto
{
    static void Main()
    {
        WriteLine("**********************************");
        WriteLine("* The stars shine in Greenville. *");
        WriteLine("**********************************");
    }
}
