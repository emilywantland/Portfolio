﻿using static System.Console;
class DebugOne3
{
    static void Main()
    {
        WriteLine("This program lists the number 1 to 5 vertically");
        WriteLine("1");
        WriteLine("2");
        WriteLine("3");
        WriteLine("4");
        WriteLine("5");
    }
}
