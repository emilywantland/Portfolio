﻿using static System.Console;
class TipCalculation
{
    static void Main()
    {
        DisplayTipInfo(34.99, 5);
    }
    
    public static void DisplayTipInfo(double price, double tipRate)
    {
        double tipInDollars;
        double total;

        tipInDollars = price * tipRate;
        total = price + tipInDollars;

        WriteLine($"Meal price: {price:C}. Tip percent: {tipRate:F}");
        WriteLine($"Tip in dollars: {tipInDollars:C}.  Total bill {total:C}");
    }

    public static void DisplayTipInfo(double price, int tipInDollars)
    {
        double tipRate;
        double total;

        tipRate = tipInDollars / price;
        total = price + tipInDollars;

        WriteLine($"Meal price: {price:C}. Tip percent: {tipRate:F}");
        WriteLine($"Tip in dollars: {tipInDollars:C}.  Total bill {total:C}");
    }
}