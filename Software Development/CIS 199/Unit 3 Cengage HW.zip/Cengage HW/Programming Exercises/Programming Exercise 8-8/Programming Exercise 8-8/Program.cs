﻿using static System.Console;
class Movie
{
    static void Main()
    {
        DisplayMovie("Titanic", 182);
        DisplayMovie("Wonder Woman");
    }
    public static void DisplayMovie(string name, int runningTime = 90)
    {
        WriteLine($"The movie {name} has a running time of {runningTime} minutes.");
    }
}