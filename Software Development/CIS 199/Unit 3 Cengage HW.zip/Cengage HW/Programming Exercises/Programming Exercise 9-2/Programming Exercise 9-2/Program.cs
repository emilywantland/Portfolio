﻿using static System.Console;
public class TestClassifiedAd
{
    public static void Main()
    {
        ClassifiedAd ad1 = new ClassifiedAd();
        ad1.Category = "Used Cars";
        ad1.Words = 100;

        ClassifiedAd ad2 = new ClassifiedAd();
        ad2.Category = "Help Wanted";
        ad2.Words = 60;

        WriteLine($"The classified ad with {ad1.Words} words in category {ad1.Category} costs {ad1.Price:C}");
        WriteLine($"The classified ad with {ad2.Words} words in category {ad2.Category} costs {ad2.Price:C}");
    }
}

class ClassifiedAd
{
    public string Category { get; set; }
    public int Words { get; set; }

    public double Price
    {
        get { return Words * 0.09; }
    }
}