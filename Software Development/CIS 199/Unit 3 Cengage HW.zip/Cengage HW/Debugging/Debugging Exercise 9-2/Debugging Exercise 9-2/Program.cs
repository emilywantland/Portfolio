﻿// Creates a Breakfast class
// and instantiates an object
// Displays Breakfast special information

using static System.Console;
class DebugNine2
{
    static void Main()
    {
        Breakfast special = new Breakfast("French toast", 4.99);
        WriteLine(Breakfast.INFO);
        WriteLine($"Today we are having {special.Name} for {special.Price:C}");
    }
}

class Breakfast
{
    public const string INFO = "Breakfast is the most important meal of the day.";

    public Breakfast(string name, double price)
    {
        Name = name;
        Price = price;
    }

    public string Name { get; set; }
    public double Price { get; set; }
}