﻿// Program 4
// CIS 200-01
// Fall 2019
// Due: 11/25/2019
// By: M1791

// File: TestParcels.cs
// This program demonstrates the use of List's Sort method with
// Parcel objects modified to support a natural order
// and the use of List's Sort method with a Comparer.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            Address a1 = new Address("John Smith", "123 Any St.", "Apt. 45", "Louisville", "KY", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.", "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321", "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7", "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Microsoft Corporation", "One Microsoft Way", "Redmond", "WA", 98052); // Test Address 5
            Address a6 = new Address("Googleplex", "1600 Amphitheatre Parkway", "Moutain View", "CA", 94043); // Test Address 6
            Address a7 = new Address("IBM North America", "590 Madison Avenue", "New York", "NY", 10022); // Test Address 7
            Address a8 = new Address("HP Inc.", "1501 Page Mill Road", "Office #65", "Palo Alto", "CA", 94304); // Test Address 8

            Letter l1 = new Letter(a1, a2, 3.95M); // Letter Test Object 1
            Letter l2 = new Letter(a3, a6, 2.35M); // Letter Test Object 2
            GroundPackage gp1 = new GroundPackage(a4, a8, 14, 10, 5, 12.5); // Ground Test Object 1
            GroundPackage gp2 = new GroundPackage(a3, a4, 10, 6, 3, 7.5);   // Ground Test Object 2
            NextDayAirPackage ndap1 = new NextDayAirPackage(a5, a3, 25, 15, 15, 5, 7.50M);     // Next Day Test Object 1
            NextDayAirPackage ndap2 = new NextDayAirPackage(a6, a7, 15, 12, 6.5, 10.5, 2.50M); // Next Day Test Object 2
            NextDayAirPackage ndap3 = new NextDayAirPackage(a8, a5, 17, 11, 8.5, 50.5, 3.50M); // Next Day Test Object 3
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a7, a2, 45.5, 40.5, 28.0, 80.5, TwoDayAirPackage.Delivery.Saver); // Two Day Test Object 1
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a6, a8, 30.5, 20.5, 25.0, 12, TwoDayAirPackage.Delivery.Early);   // Two Day Test Object 1
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a7, a1, 10, 15.5, 5.0, 60, TwoDayAirPackage.Delivery.Early);      // Two Day Test Object 3

            List<Parcel> parcels; // List of Test Parcels
            
            parcels = new List<Parcel>();

            // Populate List
            parcels.Add(l1);
            parcels.Add(l2);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);
            
            WriteLine("Original List:"); // Original List of of Items as Added to the List
            WriteLine("==============\n");
            foreach (Parcel p in parcels)
            {
                WriteLine($"{p}\n");
                WriteLine("====================\n");
            }
            Pause();
            
            parcels.Sort(); // Sort - Uses Natural Order
            WriteLine("Sorted List (Natural Order):");
            WriteLine("============================\n");
            foreach (Parcel p in parcels)
            {
                WriteLine($"{p}\n");
                WriteLine("====================\n");
            }
            Pause();
            
            parcels.Sort(new DescendingParcelOrder()); // Sort - Uses Specified Comparer Class
            WriteLine("Sorted List (Descending Natural Order) Using Comparer:");
            WriteLine("======================================================\n");
            foreach (Parcel p in parcels)
            {
                WriteLine($"{p}\n");
                WriteLine("====================\n");
            }
            Pause();

            parcels.Sort(new AscendingParcelOrder()); // Sort - Uses Specified Comparer Class
            WriteLine("Sorted List (Ascending Parcel and Descending Cost Order) Using Comparer:");
            WriteLine("========================================================================\n");
            foreach (Parcel p in parcels)
            {
                WriteLine($"{p}\n");
                WriteLine("====================\n");
            }
            Pause();
        }
        
        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();
            
            Console.Clear(); // Clear screen
        }
    }
}
