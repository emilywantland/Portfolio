﻿// Program 4
// CIS 200-01
// Fall 2019
// Due: 11/25/2019
// By: M1791

// File: DescendingParcelOrder.cs
// This class provides an IComparer for the Parcel class
// that orders the objects in ascending order by parcel 
// type and then descending order by cost.
// Lower structure based on the CompareTo() Method in Time2
// for multi-level sort ordering.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class AscendingParcelOrder : IComparer<Parcel>
    {
        // Precondition:  None
        // Postcondition: Parcel type ordered ascending and then cost ordered descending
        //                When parcel2 is null, method returns positive #
        //                When parcel1 and parcel2 are null, method returns zero
        //                When parcel1 is null, method returns negative #
        public int Compare(Parcel p1, Parcel p2)
        {
            if (p1 == null && p2 == null) // Both are null
            {
                return 0;
            }
            if (p1 == null) // Only parcel1 is null
            {
                return -1;
            }
            if (p2 == null) // Only parcel2 is null
            {
                return 1;
            }

            // Parcels in ascending order
            int ascendingParcelType = p1.GetType().ToString().CompareTo(p2.GetType().ToString()); // Variable to hold sort to be returned

            if (ascendingParcelType != 0)
            {
                return ascendingParcelType;
            }
            else
            {
                // Cost in descending order
                return p2.CalcCost().CompareTo(p1.CalcCost());
            }
        }
    }
}
