﻿// Program 4
// CIS 200-01
// Fall 2019
// Due: 11/25/2019
// By: M1791

// File: DescendingParcelOrder.cs
// This class provides an IComparer for the Parcel class
// that orders the objects in descending order.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class DescendingParcelOrder : IComparer<Parcel>
    {
        // Precondition:  None
        // Postcondition: Reverses natural parcel order, so descending
        //                When parcel2 is null, method returns positive #
        //                When parcel1 and parcel2 are null, method returns zero
        //                When parcel1 is null, method returns negative #
        public int Compare(Parcel p1, Parcel p2)
        {
            if (p1 == null && p2 == null) // Both are null
            {
                return 0;
            }
            if (p1 == null) // Only parcel1 is null
            {
                return -1;
            }
            if (p2 == null) // Only parcel2 is null
            {
                return 1;
            }

            // Reverses natural order, so descending
            return (p2.DestinationAddress.Zip).CompareTo(p1.DestinationAddress.Zip);
        }
    }
}
